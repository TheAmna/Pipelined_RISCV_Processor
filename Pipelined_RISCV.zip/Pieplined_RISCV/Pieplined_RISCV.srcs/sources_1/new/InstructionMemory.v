`timescale 1ns / 1ps  //WORD ADDRESSABLE INSTUCTION MEM = 32 bits / 4 bytes
//   we fill ALL 64 slots with 32'h00000063 BEFORE $readmemh runs. $readmemh
//   then overwrites slots 0..19 with the real program, and any speculative fetch
// past the end now decodes as another harmless trap-loop branch instead of X.
//   Choice of fill value:
//     32'h00000013 - canonical RISC-V NOP (addi x0,x0,0).
//     32'h00000000 - decodes via MainControl default as all-zero control signals (NOP).
module InstructionMemory #(
    parameter OPERAND_LENGTH = 31
)(
    input  [OPERAND_LENGTH:0] instAddress, // PC - byte address from processor
    output reg [31:0]         instruction  // 32-bit instruction word output
);
    // 64 words of 32 bits = 256 bytes 
    reg [31:0] memory [0:63];
    integer i;
    initial begin
        // Step 1: pre-fill every slot with a values other than X
        for (i = 0; i < 64; i = i + 1) begin
            memory[i] = 32'h00000063;   // EXIT/trap: beq x0, x0, 0
        end
        // Step 2: load the actual program. Overwrites slots
        $readmemh("instruction.mem", memory);
    end
    // Combinational read, PC is a byte address so divide by 4 to get the word index.
    always @(*) begin
        if ((instAddress >> 2) < 64)
            instruction = memory[instAddress >> 2];
        else
            instruction = 32'h00000063;  // out-of-range fetch -> trap
    end
endmodule


